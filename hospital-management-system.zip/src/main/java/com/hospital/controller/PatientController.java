package com.hospital.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import com.hospital.model.Patient;
import com.hospital.service.PatientService;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService service;

    public PatientController(PatientService service) {
        this.service = service;
    }

    @PostMapping
    public Patient add(@RequestBody Patient p) {
        return service.save(p);
    }

    @GetMapping
    public List<Patient> getAll() {
        return service.getAll();
    }
}
